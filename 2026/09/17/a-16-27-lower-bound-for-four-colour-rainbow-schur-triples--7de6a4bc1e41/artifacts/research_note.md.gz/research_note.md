# A 16/27 lower bound for four-colour rainbow Schur triples
**Status:** SAME_MODEL_REVIEW_PASS
**Research area:** additive combinatorics / anti-Ramsey multiplicity for Schur triples  

## Slogan

A residue–interval 4-coloring raises the known asymptotic lower bound for rainbow Schur triples from 10/21 to 16/27.

## Literature gap

Hegde, Kumar and Pratibha, *A somewhat sure note on an un-Schur problem* (arXiv:2609.18474v1, 16 Sep 2026), extend the anti-Ramsey Schur-triple problem from 3 colors to general k. They prove

    (k-2)(k+1)/((k-1)(k+3)) <= liminf Lambda_{n,k} <= limsup Lambda_{n,k} <= 1-1/k,

and explicitly state that their general bounds are likely not optimal and that the k=4 case is worth further investigation. For k=4 their lower bound is 10/21 ≈ 0.476190.

The earlier paper of Parczyk and Spiegel, *An Unsure Note on an Un-Schur Problem*, Electronic Journal of Combinatorics 33(1) (2026), #P1.45, introduced the multiplicity problem in the 3-color case.

## Definitions

For a k-coloring c:[n]->[k], let R_n(c) be the ordered pairs (x,y) of positive integers with x+y<=n such that c(x), c(y), c(x+y) are pairwise distinct. There are binom(n,2) ordered pairs with x+y<=n. Define

    Lambda_{n,k} = max_c |R_n(c)| / binom(n,2).

## Main claim

**Theorem.**

    liminf_{n->infinity} Lambda_{n,4} >= 16/27.

Hence the currently published interval for k=4 improves from

    10/21 <= liminf Lambda_{n,4} <= limsup Lambda_{n,4} <= 3/4

to

    16/27 <= liminf Lambda_{n,4} <= limsup Lambda_{n,4} <= 3/4.

Numerically, 16/27 ≈ 0.592593.

## Construction

Use colors A,B,C,D. For x in [n]:

- if x ≡ 0 (mod 3), color x by A;
- if x not ≡ 0 (mod 3) and x <= n/4, color x by B;
- if n/4 < x <= 2n/3, color residue 1 mod 3 by C and residue 2 mod 3 by D;
- if x > 2n/3, swap C and D: residue 1 gets D and residue 2 gets C.

Boundary rounding changes only O(n) triples and is asymptotically irrelevant.

## Proof

Scale x/n and y/n to the triangle

    T = {(u,v): u>0, v>0, u+v<=1},

which has area 1/2. Let

    L=(0,1/4],  M=(1/4,2/3],  H=(2/3,1].

For each fixed ordered residue pair (r,s) mod 3, lattice points in a polygonal subregion of T have asymptotic density 1/9, so it suffices to compute the Euclidean area on which the three colors are distinct.

### 1. Residue pair (0,0)

All three terms have color A. Good area: 0.

### 2. One summand has residue 0

For (0,1), (0,2), (1,0), or (2,0), the residue-0 summand has color A, while the other summand and the sum have the same nonzero residue. Since the sum is larger than that summand, failure occurs exactly when those two scaled values lie in the same one of L,M,H.

The three failure areas are

    area(L,L same-bin) = (1/4)^2/2 = 1/32,
    area(M,M same-bin) = (2/3-1/4)^2/2 = 25/288,
    area(H,H same-bin) = (1-2/3)^2/2 = 1/18.

Their sum is 25/144, hence each of the four ordered residue types has good area

    1/2 - 25/144 = 47/144.

### 3. Equal nonzero residues

Consider (1,1); the case (2,2) is symmetric. The sum has residue 2. A rainbow triple occurs exactly in either of these ordered configurations:

- one summand is in L, the other in M, and the sum remains in M;
- one summand is in L, the other in H (the sum is then in H).

For one orientation the corresponding areas are

    area(L x M, u+v<=2/3) = 7/96,
    area(L x H, u+v<=1)   = 5/96.

Including both orientations gives

    2(7/96+5/96) = 1/4.

Thus each of (1,1) and (2,2) has good area 1/4.

### 4. Distinct nonzero residues

For (1,2) or (2,1), the sum has residue 0 and color A, so it is enough that the two summands receive different colors.

They have the same color only in three situations:

- both lie in L: area 1/16;
- residue 1 lies in M while residue 2 lies in H: feasible area 1/288;
- residue 1 lies in H while residue 2 lies in M: feasible area 1/288.

Thus the failure area is

    1/16 + 2/288 = 5/72,

so each mixed nonzero residue pair has good area

    1/2 - 5/72 = 31/72.

### 5. Summation

Summing the good areas over the nine ordered residue pairs gives

    4*(47/144) + 2*(1/4) + 2*(31/72) = 8/3.

Each ordered residue pair occupies asymptotically 1/9 of the integer lattice, hence

    |R_n(c)| = (1/9)*(8/3)n^2 + O(n)
             = (8/27)n^2 + O(n).

Since

    binom(n,2) = n^2/2 + O(n),

we obtain

    |R_n(c)| / binom(n,2) -> 16/27.

Therefore

    liminf Lambda_{n,4} >= 16/27.

For n divisible by 36, direct exact counting gives the stronger finite identity

    |R_n(c)| = 8n^2/27 + 5n/18,

which is independently checked in the accompanying script for several values of n. The asymptotic theorem does not rely on this empirical identity.

## Reproducible computational material

The accompanying pure-Python certificate uses exact rational arithmetic to:

1. compute all nine residue-pair areas by inclusion-exclusion;
2. verify their values 0, 47/144, 1/4, and 31/72;
3. recover the total coefficient 8/27 and fraction 16/27;
4. brute-force finite n divisible by 36 and verify the exact formula above.

No floating-point inequality is used in the mathematical certificate.

## Candidate/approach summary

The construction is motivated by the newly posted general-k extension because its authors explicitly identify k=4 as worth further investigation. Pure periodic colorings modulo small moduli were checked first and did not approach the new paper's bound. Finite local-search experiments then repeatedly exposed a stable hybrid pattern: one residue class fixed, with two nonzero residue classes changing roles across two interval cuts. Abstracting that pattern led to the explicit construction above. Local search initialized at the construction did not improve it in the tested finite instances; this is only a diagnostic and is not used as evidence for optimality.

## Closest prior work and originality checks

1. **Hegde–Kumar–Pratibha (2026), arXiv:2609.18474v1.** This is the closest source. It states the general-k lower bound and explicitly says the k=4 case merits further investigation. Its k=4 lower bound is 10/21, not 16/27.
2. **Parczyk–Spiegel (2026), EJC 33(1), #P1.45.** This paper formulates the multiplicity problem for 3 colors and does not provide the present 4-color bound.
3. Searches were performed for exact and equivalent formulations including "16/27 rainbow Schur", "4-color rainbow Schur triples", "k=4 rainbow Schur triples", and modular/residue formulations. No indexed source stating this bound or a stronger bound for the same parameter was found.

Because arXiv:2609.18474 is only about one day old, unpublished author calculations, very recent revisions, or unindexed notes are the most plausible originality threats.

## Same-model review

### Correctness: PASS

The proof reduces to an explicit deterministic coloring and elementary planar-area counts. The residue-pair decomposition covers all nine ordered residue pairs. The area calculations were independently recomputed by exact rational inclusion-exclusion, and direct finite counts converge to the claimed limit. Boundary rounding affects only O(n) pairs.

### Originality: QUALIFIED PASS

To the best of our knowledge, the lower bound 16/27 for the k=4 anti-Ramsey Schur multiplicity is not present in accessible indexed literature as of 17 Sep 2026. The strongest accessible directly relevant source, posted 16 Sep 2026, gives only 10/21 and flags k=4 as open for improvement. The principal threat is unpublished or not-yet-indexed follow-up work by the same authors or others reacting to the new preprint.

### Value: PASS

This is not a numerical-instance extension. It improves the first published nontrivial k=4 lower bound from 10/21 ≈ 0.47619 to 16/27 ≈ 0.59259, an absolute gain of about 0.11640 and a relative increase of about 24.4% in the guaranteed rainbow fraction. It also supplies a simple deterministic structure—mod 3 combined with two interval cuts—that may be useful for further extremal analysis.

## Limitations and threatening inaccessible sources

- The result is a lower bound, not the exact k=4 asymptotic value.
- No upper-bound improvement was obtained.
- The construction is not claimed optimal, even within all structured modular/interval colorings.
- The most serious originality threat is unpublished or extremely recent work following arXiv:2609.18474.
- Search engines may not yet index all 16–17 Sep 2026 revisions or private communications.

