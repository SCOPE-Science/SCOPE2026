# SCOPE Web Research — Run SCOPE-20260917T100054Z-R02

**UTC start:** 2026-09-17 10:00:54  
**UTC end:** 2026-09-17 10:15:37  
**Status:** SELF_AUDIT_PASS  
**Delivery:** SEND_BLOCKED — Outlook returned HTTP 403 `ErrorAccountSuspend` (account suspended; verification required). An earlier attachment-bearing attempt was rejected before dispatch because local files were unavailable for connector egress. No email was sent.  
**Classification:** Valuable unexpected finding (not a late-stage smaller target)

## Research area and gap

Finite combinatorics / incidence geometry / the Non-Cancelling Intersections (NCI) conjecture.

Hermann Wilhelm's recent preprint, *Refutation of the Non-Cancelling-Intersections Conjecture* (arXiv:2608.27416, v2 dated 2026-08-31), disproves unrestricted NCI by constructing lattices \(P_{p,m}\) from marked affine planes. The published quantitative statement requires prime \(p\ge 10^5\), and the smallest prime used there, \(p=100003\), yields a lattice with fewer than \(1.1\times 10^{15}\) elements. The paper explicitly notes that its first-moment estimate has enormous slack and asks how small a counterexample lattice can be; it also notes that the argument is nonconstructive and does not provide an explicit marking.

Primary source: https://arxiv.org/abs/2608.27416

The initial target of this run was stronger: try to obtain an explicit small marking by computational search. That attempt stalled on the adversarial admissible-set subproblem. While auditing why the published first-moment proof needs such a large prime, a different substantive opportunity appeared: retain the same probabilistic construction but use the exact hypergeometric trace-hit probability and a sharper variable trace-count estimate.

## Independence check

The accessible previous run concerned generalized strong-majority edge-colourings of bipartite graphs. This run deliberately moved to a disjoint topic: finite affine geometry and NCI lattices. No theorem, method, parameter family, or unfinished plan from the previous run was used as a starting point.

The execution environment exposes no hard cross-run activity lock, so non-overlap cannot be mechanically certified. No evidence of an earlier still-active execution was accessible when this run began.

## Definitions

Let \(p\) be a prime and let \(\mathbb F_p^2\) be the affine plane. A **marking** \(m\) assigns to each affine line \(\ell\) a set \(m(\ell)\subseteq \ell\) of exactly
\[
w=\lceil\sqrt{2p}\rceil+1
\]
marked points.

For \(T\subseteq\mathbb F_p^2\), write \(j_\ell=|T\cap\ell|\). Following Wilhelm, \(T\) is **admissible** if every trace \(T\cap\ell\) of size at least two contains a point marked for \(\ell\).

Wilhelm proves two structural facts used below:

1. Any winning plane dot-algebra tree contains an admissible node-state \(T\) with \(2p\le |T|\le4p-2\) (Lemma 4.2).
2. If the lattice \(P_{p,m}\) has a winning dot-algebra tree, then the corresponding marked plane has a winning plane dot-algebra tree (Lemma 6.1).

Thus a marking with no admissible \(T\) of size \(2p\) through \(4p\) yields an NCI counterexample lattice.

## Main claim

### Theorem
For \(p=571\) there exists a marking \(m\) with \(|m(\ell)|=35\) for every affine line \(\ell\subseteq\mathbb F_{571}^2\) such that no admissible set \(T\) satisfies
\[
1142\le |T|\le2284.
\]
Consequently, \(P_{571,m}\) admits no winning dot-algebra tree and is an NCI counterexample lattice with exactly
\[
571^3+2\cdot571^2+2=186,821,495
\]
elements.

This reduces the explicit numerical upper bound furnished by Wilhelm's \(p=100003\) construction by a factor of about \(5.35\times10^6\) in lattice size. The marking remains nonconstructive: existence is proved by the first moment method.

## Proof

Fix \(p=571\), \(w=35\), and put \(K=19\). Let \(T\subseteq\mathbb F_p^2\) have \(t=|T|\in[2p,4p]\). For each affine line \(\ell\), set \(j_\ell=|T\cap\ell|\).

The standard affine-plane identities, also used in Wilhelm's Lemma 7.1, are
\[
\sum_\ell j_\ell=t(p+1),\qquad
\sum_\ell \binom{j_\ell}{2}=\binom t2,
\]
so
\[
\sum_\ell j_\ell^2=t(t+p).
\]

Let \(N\) be the number of lines with \(j_\ell\ge2\). As in Wilhelm's Cauchy-Schwarz step, but retaining the exact dependence on \(t\),
\[
N\ge A(t):=\frac{(p+1)^2(t-p)^2}{t(t+p)}.
\]
The number of lines with \(j_\ell\ge20\) is at most
\[
\frac{1}{20}\sum_\ell j_\ell=\frac{t(p+1)}{20}.
\]
Hence the number of lines whose traces have sizes \(2,3,\ldots,19\) is at least
\[
S(t):=\frac{(p+1)^2(t-p)^2}{t(t+p)}-\frac{t(p+1)}{20}. \tag{1}
\]

Choose the marking randomly and independently line by line, each \(m(\ell)\) being a uniformly random 35-subset of \(\ell\). A fixed trace of size at most 19 is hit with probability at most
\[
q=1-\frac{\binom{571-19}{35}}{\binom{571}{35}}
 =1-\frac{\binom{552}{35}}{\binom{571}{35}}
 <\frac{353}{500}. \tag{2}
\]
Because markings on distinct lines are independent, a fixed \(T\) is admissible with probability at most
\[
(353/500)^{S(t)}. \tag{3}
\]

Let
\[
b_t:=\binom{p^2}{t}(353/500)^{S(t)}.
\]
Then the expected number of admissible sets with sizes from \(2p\) to \(4p\) is at most \(\sum_{t=2p}^{4p}b_t\).

Differentiate the first term of (1):
\[
A'(t)=\frac{p(p+1)^2(t-p)(p+3t)}{t^2(p+t)^2}.
\]
Writing \(x=t/p\), the nonconstant factor is
\[
g(x)=\frac{(x-1)(1+3x)}{x^2(1+x)^2}.
\]
For \(x\in[2,4]\),
\[
g'(x)=-\frac{2(3x^3-3x^2-3x-1)}{x^3(1+x)^3}<0,
\]
so \(A'(t)\) is minimized at \(t=4p\). Therefore
\[
S'(t)\ge \frac{(p+1)^2}{p}\frac{39}{400}-\frac{p+1}{20}
 =\frac{389246}{14275}>27. \tag{4}
\]
Consequently \(S(t+1)-S(t)>27\). Since \(t\ge2p\),
\[
\frac{b_{t+1}}{b_t}
=\frac{p^2-t}{t+1}(353/500)^{S(t+1)-S(t)}
<\frac p2(353/500)^{27}<\frac1{40}. \tag{5}
\]

At the first size \(t=2p\),
\[
S(2p)=\frac{(p+1)^2}{6}-\frac{2p(p+1)}{20}
=\frac{328042}{15}>21869.
\]
Using \(\binom nk\le(en/k)^k\) and \(e<11/4\),
\[
b_{2p}
<\left(\frac{11p}{8}\right)^{2p}(353/500)^{21869}
<\frac7{20}. \tag{6}
\]
The two final inequalities in (5) and (6), as well as (2) and (4), were checked exactly with integer/rational arithmetic in the attached certificate script.

The geometric tail now gives
\[
\mathbb E[\#\{\text{admissible medium }T\}]
<\frac{7/20}{1-1/40}
=\frac{14}{39}<1.
\]
Hence some marking contains no admissible set of size between \(2p\) and \(4p\).

Wilhelm's Lemma 6.1 then converts any hypothetical winning dot-algebra tree on \(P_{p,m}\) into a winning plane tree, and Lemma 4.2 would force an admissible node-state of size between \(2p\) and \(4p-2\), contradiction. The lattice-meet argument in the paper requires \(p\ge11\), which is satisfied by \(571\). Thus \(P_{571,m}\) is an NCI counterexample.

## Reproducible computational material

Attached script: `SCOPE_20260917_run02_check.py`.

It uses exact Python integers and `fractions.Fraction` to verify:

- \(571\) is prime and \(w=35\);
- the exact hypergeometric probability in (2) is \(\approx0.7053150868<353/500\);
- the derivative lower bound in (4) is \(\approx27.26767075>27\);
- the successive-term ratio bound in (5) is \(\approx0.02362289<1/40\);
- \(S(2p)=21869.466\ldots>21869\);
- the exact big-integer comparison giving (6);
- the total expectation bound \(14/39<1\);
- the lattice size \(186,821,495\).

As an additional audit, a scan of primes below 571 and all permissible integer cutoffs \(K\) found no success under this same simple geometric-ratio certificate template. This scan is only diagnostic, not part of the theorem or an optimality claim.

## Closest prior work and coverage checks

The direct closest source is Wilhelm, arXiv:2608.27416. Its Lemma 7.2 uses a fixed trace cutoff 47, a union-bound hit estimate, and then a coarse simplification that is stated for \(p\ge10^5\). The paper itself explicitly says the first-moment estimate has enormous slack and that the cutoff 47 is inessential. Its Theorem 8.1 and Corollary 8.2 then use \(p=100003\), and Remark 8.3 gives the lattice size formula \(p^3+2p^2+2\). Section 9 asks for explicit counterexamples and lower bounds on the smallest lattice.

Fresh searches on 2026-09-17 included the exact values `571`, `186821495`, combinations with `Non-Cancelling Intersections`, and searches for improved quantitative bounds around arXiv:2608.27416. No indexed source stating the \(p=571\) bound, this exact certificate, or a stronger accessible quantitative bound was found.

The original NCI conjecture is due to Amarilli, Monet and Suciu (arXiv:2401.16210). Recent positive sufficient-condition work for restricted/join-tree settings does not appear to imply a quantitative counterexample bound for Wilhelm's construction.

## Self-audit

### Correctness: PASS

The argument only sharpens the probabilistic part of an existing structural reduction. Every new numerical inequality needed for the claimed prime is checked with exact integer/rational arithmetic. Boundary requirements were checked: \(571\) is prime, \(w=35\), and \(p\ge11\) satisfies the lattice construction's meet condition. The probability step uses independence only across distinct affine lines, exactly as in Wilhelm's random marking.

A subtle point was checked explicitly: the lower bound \(S(t)\) need not be integral, but the actual number of short traces is an integer at least \(S(t)\); since the hit-probability base is below one, replacing the integer exponent by \(S(t)\) is a valid upper bound.

### Originality: QUALIFIED PASS

To the best of our knowledge, the quantitative \(p=571\) theorem and the resulting 186,821,495-element upper bound are not present in accessible indexed literature as of 2026-09-17. The recent source itself only states \(p\ge10^5\) and the \(p=100003\) numerical construction.

The most important threats are extremely recent or unpublished work. Wilhelm's paper mentions independent private work by Alexander Walz on the unrestricted refutation; the accessible description indicates a much larger/tower-type parameter, but private details cannot be checked. Wilhelm or others could also have an unpublished sharpened first-moment calculation. Therefore the originality claim is deliberately qualified.

### Value: PASS (quantitatively strong, conceptually moderate)

The conceptual mechanism is not new: it remains Wilhelm's first-moment construction. The value is quantitative and concrete. The smallest lattice supplied by the published theorem has
\[
100003^3+2\cdot100003^2+2=1,000,110,003,900,047
\]
elements, whereas the present certificate gives \(186,821,495\), a reduction by a factor of about 5.35 million. This directly addresses the paper's question of reducing counterexample size, although it does not address the harder demand for an explicit marking or determine the true smallest counterexample.

## Limitations and potentially threatening inaccessible sources

1. The marking is existential, not explicitly constructed.
2. No claim is made that \(p=571\) is the smallest prime for which a marking exists; it is only certified by this sharpened first-moment argument.
3. The private Alexander Walz work cited by Wilhelm is inaccessible and could contain overlapping quantitative observations, although the public description does not suggest this scale.
4. Very recent manuscripts, author notes, or revisions not yet indexed could overlap.
5. The result depends on Wilhelm's structural Lemmas 4.2 and 6.1 and the lattice construction; it is not an independent reconstruction of the entire NCI refutation from first principles.

## Attempted candidates / approaches

The substantive initial target was an explicit small-prime marking. Random-marking MILP checks for several small primes (including 7, 11, 13, 17, and 19) continued to admit medium admissible sets; larger small-prime adversarial solves became expensive, and a constraint-generation attempt did not reach a certificate. This route was therefore not claimed as a result.

Auditing the bottleneck in the published first-moment proof then produced the present result: reduce the trace cutoff, retain the exact dependence of the Cauchy-Schwarz trace count on \(|T|\), and use the exact hypergeometric hit probability instead of the coarse union-bound simplification. Because this yielded a substantial quantitative theorem, it was returned immediately rather than downgraded or padded to consume the remaining time budget.

## Slogan

**A sharper first-moment count shrinks Wilhelm's NCI counterexample from about a quadrillion lattice elements to under 187 million.**
