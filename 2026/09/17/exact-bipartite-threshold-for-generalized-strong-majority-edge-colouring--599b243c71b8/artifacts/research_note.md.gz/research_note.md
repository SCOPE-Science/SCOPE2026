# Exact bipartite threshold for generalized strong-majority edge colouring
**Status:** SAME_MODEL_REVIEW_PASS  
**Area:** Graph colouring — generalized strong majority edge colourings

## Slogan

**For bipartite graphs, the strong `1/k`-majority `(k+1)`-edge-colouring threshold is exactly `k^2+1`, with `K_{k^2,k^2+1}` giving the sharp obstruction.**

## Why this gap matters

Pękała and Przybyło introduced strong `1/k`-majority edge colourings in August 2026 and proved that minimum degree `2k^2+1` suffices in general. They explicitly ask for the least general threshold `δ_k` and note `k^2+1` as a tempting target. Their revised paper also records the sharp `k=2` obstruction `K_{4,5}` due to D. S. McNeil. The bipartite case is structurally distinguished because de Werra's balanced edge-colouring theorem gives discrepancy at most one at every vertex. This makes an exact bipartite threshold a natural, nontrivial subproblem of the new generalized theory.

Primary current source: P. Pękała and J. Przybyło, *On Strong Majority Edge Colourings with Few Colours*, arXiv:2608.04122v2 (6 Aug 2026), especially Section 4, Theorem 7, and Section 5, Claim 10 / Problem 11.  
https://arxiv.org/html/2608.04122v2

## Definitions

Let `k >= 2`. An edge-colouring `c:E(G)->C` is a **strong `1/k`-majority edge colouring** if, for every edge `e=uv` and every colour `α`, at most

`(d(u)+d(v)-2)/k`

edges adjacent to `e` receive colour `α`.

Let `δ_k^bip` be the least integer `d` such that every finite simple bipartite graph `G` with minimum degree `δ(G)>=d` admits a strong `1/k`-majority edge colouring with `k+1` colours.

## Main claim

### Theorem
For every integer `k>=2`,

`δ_k^bip = k^2+1`.

Thus the `k^2+1` degree scale suggested in the recent general problem is exactly correct on bipartite graphs, and the bound is sharp for every `k`.

---

## Proof — upper bound

A theorem of de Werra states that, for every bipartite graph and every positive integer `q`, there is a `q`-edge-colouring in which the numbers of incident edges of any two colours differ by at most one at every vertex. Equivalently, with `q=k+1`, for every vertex `v` and colour `α`,

`d_α(v) <= ceil(d(v)/(k+1))`.

This result is quoted as Theorem 16 in Kalinowski–Kamyczura–Pilśniak–Woźniak, *Strong majority colorings of graphs*, arXiv:2605.23828 (May 2026), which gives `D_q(G)<=1` for bipartite graphs.  
https://arxiv.org/html/2605.23828v1

We need the elementary inequality

`ceil(d/(k+1)) <= (d-1)/k`  for every integer `d>=k^2+1`.    (1)

To verify it, write `d=(k+1)t+r`, with `0<=r<=k`.

- If `r=0`, then the left side is `t`; inequality (1) is `kt <= (k+1)t-1`, true for `t>=1`.
- If `r>0`, the left side is `t+1`; inequality (1) becomes `t+r>=k+1`. Since
  `d>=k^2+1=(k+1)(k-1)+2`, either `t>=k`, or `t=k-1` and `r>=2`; in either case `t+r>=k+1`.

Now assume `G` is bipartite and `δ(G)>=k^2+1`, and take a de Werra balanced `(k+1)`-edge-colouring. For any edge `e=uv` and colour `α`, the number of `α`-coloured edges adjacent to `e` is at most

`d_α(u)+d_α(v)`

(the actual number is two smaller if `e` itself has colour `α`). Hence, by (1),

`# adjacent α-edges <= (d(u)-1)/k + (d(v)-1)/k = (d(u)+d(v)-2)/k`.

So the colouring is strong `1/k`-majority. Therefore

`δ_k^bip <= k^2+1`.

---

## Proof — sharp lower bound

Take

`G = K_{k^2, k^2+1}`,

with bipartition `X,Y`, where `|X|=k^2` and `|Y|=k^2+1`. Its minimum degree is `k^2`.

Every edge of `G` has

`(k^2+1-1)+(k^2-1)=2k^2-1`

adjacent edges. Therefore, in a strong `1/k`-majority colouring, at most

`floor((2k^2-1)/k)=2k-1`    (2)

adjacent edges can have any fixed colour.

Fix one colour `α`, and let `H` be the spanning subgraph consisting of the `α`-coloured edges. For every pair `x in X`, `y in Y`, because `xy` is an edge of the ambient complete bipartite graph, (2) gives

`d_H(x)+d_H(y)-2*1_{xy in E(H)} <= 2k-1`.    (3)

Call a vertex **high** when its degree in `H` is at least `k`.

### Structural consequences of (3)

If `x` and `y` are both high, then `xy` must belong to `H`; otherwise their degree sum is at least `2k`, contradicting (3). Hence all high vertices on opposite sides are mutually adjacent in `H`.

If high vertices occur on both sides, then for every high pair `x,y`, equation (3) with `xy in H` yields

`d_H(x)+d_H(y) <= 2k+1`.

Thus in this two-sided-high case every high vertex has degree at most `k+1`.

We now prove the one-colour extremal bound

`|E(H)| <= M_k := k^3-k^2+k`.    (4)

### Case A: one side has no high vertex

If `X` has no high vertex, summing degrees on `X` gives

`|E(H)| <= k^2(k-1) <= M_k`.

If `Y` has no high vertex, then

`|E(H)| <= (k^2+1)(k-1) = M_k-1`.

### Case B: both sides have high vertices, and no high vertex has degree `k+1`

Then every high vertex has degree exactly `k`. Let `p` be the number of high vertices in `X`. Pick any high vertex `y in Y`. Since all high vertices across the bipartition are mutually adjacent, `y` is adjacent to all `p` high vertices of `X`; because `d_H(y)=k`, we have `p<=k`.

Summing degrees on `X`,

`|E(H)| <= p*k + (k^2-p)(k-1)`
`         = k^2(k-1)+p`
`         <= k^2(k-1)+k = M_k`.

### Case C: both sides have high vertices, and some high vertex has degree `k+1`

Suppose first `x_0 in X` has degree `k+1`. Every high `y in Y` must then have degree exactly `k`, because `d_H(x_0)+d_H(y)<=2k+1`. Moreover, every `y in Y` of degree `k-1` must be adjacent to `x_0`: if not, (3) would give

`(k+1)+(k-1) <= 2k-1`,

which is false. Hence every vertex of `Y` with degree at least `k-1` lies among the `k+1` neighbours of `x_0`. Those vertices have degree at most `k`; all other vertices of `Y` have degree at most `k-2`. Therefore

`|E(H)| <= (k+1)k + (k^2-k)(k-2)`
`         = k^3-2k^2+3k`
`         <= M_k`,

where the last difference is `k(k-2)>=0`.

If instead a vertex `y_0 in Y` has degree `k+1`, the symmetric argument, now summing over `X`, gives

`|E(H)| <= (k+1)k + (k^2-k-1)(k-2)`
`         = k^3-2k^2+2k+2`
`         <= M_k`,

with difference `(k-2)(k+1)>=0`.

A degree-`k+1` high vertex cannot occur on both sides simultaneously: such a pair would have to be adjacent, but then its degree sum `2k+2` would violate the bound `2k+1` for adjacent high pairs.

This proves (4) in all cases.

### Capacity contradiction

A strong colouring with `k+1` colours would partition all edges of `G` into `k+1` colour classes, each containing at most `M_k` edges. Hence it could colour at most

`(k+1)M_k = (k+1)(k^3-k^2+k) = k^4+k`

edges. But

`|E(K_{k^2,k^2+1})| = k^2(k^2+1) = k^4+k^2`,

and `k^4+k < k^4+k^2` for every `k>=2`. Contradiction.

Therefore `K_{k^2,k^2+1}` is not strong `1/k`-majority `(k+1)`-edge-colourable, so

`δ_k^bip >= k^2+1`.

Together with the upper bound,

`δ_k^bip = k^2+1`.

---

## Reproducible computational checks

Supporting script: `verify.py`.

It performs the following checks:

1. Exhaustively verifies the upper-bound arithmetic inequality for `2<=k<=100` and 501 consecutive degree values from `d=k^2+1` upward, while confirming that the corresponding inequality fails at `d=k^2`.
2. Verifies the algebra in all lower-bound cases for `2<=k<=100` (and the script supports larger ranges).
3. Formulates the one-colour extremal problem on `K_{k^2,k^2+1}` as a binary MILP using exactly constraint (3). For `k=2`, SciPy/HiGHS independently certifies optimum `6=M_2`, recovering the McNeil `K_{4,5}` obstruction. A 20-second exploratory run for `k=3` found a feasible optimum candidate of `21=M_3` but did not close the solver's dual gap; the symbolic proof above is the certificate for all `k`.

Command used for the certified small check:

```bash
python verify.py --kmax 100 --milp 2 --time-limit 5
```

Observed output included:

- upper arithmetic verified for `2<=k<=100`;
- extremal algebra verified for `2<=k<=100`;
- `k=2`: HiGHS status optimal, one-colour maximum `6`, zero MIP gap.

---

## Closest prior work and coverage audit

### 1. Pękała–Przybyło (Aug 2026): directly adjacent primary source

Their v2 paper introduces strong `1/k`-majority edge colourings and proves:

- **Theorem 7:** minimum degree `2k^2+1` suffices in general for `k+1` colours.
- **Claim 10:** `K_{4,5}` is not strong majority 3-edge-colourable, a computer-found example communicated by D. S. McNeil.
- **Problem 11:** determine the least general threshold `δ_k` for `k>=3`.
- Immediately before Problem 11 they specifically identify `k^2+1` as a tempting possible general threshold, without asserting it.

Source: https://arxiv.org/html/2608.04122v2

The present result does not solve their general Problem 11, but it exactly solves the bipartite restriction for every `k` and generalizes their `k=2` complete-bipartite obstruction.

### 2. Kalinowski–Kamyczura–Pilśniak–Woźniak (May 2026)

Their paper introduced strong majority edge colouring (`k=2`) and quotes de Werra's theorem as `D_q(G)<=1` for every bipartite graph and every number `q` of colours. It applies this discrepancy tool to the original strong-majority setting, proving a 4-colour result for bipartite graphs of minimum degree 4 and noting that analogous arguments give 3 colours for minimum degree 5.

Source: https://arxiv.org/html/2605.23828v1

This supplies the classical balancing tool used in the upper half of the theorem, but it predates the generalized strong `1/k` notion and does not state the all-`k` threshold proved here.

### 3. Pękała–Przybyło (2024): ordinary generalized majority edge colourings

This is an important terminology/equivalence check. Their `1/k`-majority condition is **vertexwise**: each colour occupies at most `1/k` of the edges incident with every vertex. They prove the exact bipartite threshold `k(k-1)` for that different problem.

Source: https://arxiv.org/abs/2309.16624

That theorem is not equivalent to the present strong edge-neighbourhood condition: ordinary majority controls each endpoint separately by `d(v)/k`, while strong majority requires a deficit of two in the combined edge neighbourhood, `(d(u)+d(v)-2)/k`, simultaneously for every edge and colour.

### Searches performed

Fresh web/arXiv searches used exact and alternate formulations including:

- `"strong 1/k-majority" bipartite`
- `"strong 1/k-majority" "k^2+1"`
- `"K_{k^2,k^2+1}" strong majority`
- `"complete bipartite" "strong 1/k-majority" edge colouring`
- `"strong 1/k-majority" de Werra`
- searches for papers citing or discussing arXiv:2608.04122 and its Problem 11.

No indexed source located the theorem `δ_k^bip=k^2+1`, the obstruction family `K_{k^2,k^2+1}` in this strong-majority context, or an equivalent stronger result.

---

## Same-model review

### Correctness — PASS

The proof is elementary once the right construction is identified, and every quantitative step was checked independently.

- The upper bound uses a published bipartite discrepancy theorem and a separately verified integer inequality.
- The lower bound converts the strong-majority condition into the exact local constraint (3), then derives a global maximum for every single colour class.
- Boundary case `k=2` reproduces the known `K_{4,5}` obstruction and the exact one-colour bound `6`, independently certified by MILP.
- Algebraic inequalities in all lower-bound cases were programmatically checked over a large finite range, in addition to the symbolic proof.
- The capacity gap is `k^2-k=k(k-1)>0`, so there is no equality-edge case hidden at the final step.

No unproved regularity, parity, or decomposition assumption is used beyond de Werra's published theorem.

### Originality — QUALIFIED PASS, to the best of our knowledge

The generalized strong `1/k` notion is only about six weeks old. The closest primary source explicitly leaves the general threshold open, records only the `k=2` complete-bipartite obstruction, and does not state an exact bipartite threshold. Exact-phrase, alternate-terminology, complete-bipartite-family, and citation-oriented searches found no prior statement of this theorem.

The upper-bound half is a short consequence of de Werra's classical balanced edge-colouring theorem once the generalized strong condition is written down. Therefore the main originality risk lies in whether someone has already noticed the same consequence and/or generalized McNeil's `K_{4,5}` obstruction privately or in a very recent unindexed note.

The most important inaccessible threat is **D. S. McNeil, personal communication, August 2026**, cited in Pękała–Przybyło v2. The paper says McNeil found `K_{4,5}` “and various other examples” by computer search. There is no concrete evidence in the accessible source that the communication contains the all-`k` family `K_{k^2,k^2+1}` or the theorem proved here, so this is treated as a disclosure-worthy possible overlap rather than evidence of likely prior coverage. A direct check with the authors/McNeil would be appropriate before public novelty claims.

Also possible, but less specific, is a post-6-August-2026 manuscript or note not yet indexed by the searches used here.

### Value — PASS

The result gives an exact threshold for an infinite structural graph class and for every parameter `k`, rather than an isolated numerical case. It:

- cuts the current general sufficient degree `2k^2+1` to the sharp `k^2+1` on bipartite graphs;
- identifies an explicit extremal family at degree `k^2`;
- generalizes the recently discovered `K_{4,5}` obstruction from `k=2` to all `k`;
- supplies evidence that the `k^2+1` scale highlighted by Pękała–Przybyło is mathematically natural in the strong generalized setting;
- combines a classical equitable-colouring theorem with a new one-colour extremal argument, producing a compact theorem suitable for a short note or proposition in follow-up work.

The upper half alone would be a modest corollary; the matching lower construction and exact threshold are what make the result substantive.

---

## Limitations and threatening inaccessible sources

1. **D. S. McNeil, personal communication (August 2026)** — inaccessible; cited by Pękała–Przybyło for `K_{4,5}` and “various other examples.” This is the clearest originality threat.
2. **Very recent/unindexed follow-up work after 6 August 2026** — the topic is new and moving quickly; web/arXiv indexing cannot guarantee completeness.
3. The search did not include private correspondence, manuscripts not publicly indexed, or closed databases beyond what the browsing environment exposed.
4. The theorem is for finite simple bipartite graphs, matching the setting of the cited strong-majority papers; multigraph variants were not audited.

---

